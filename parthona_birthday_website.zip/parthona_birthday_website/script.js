(() => {
  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // A lightweight, responsive starfield — no WebGL or external library required.
  const canvas = $('#starfield');
  const ctx = canvas.getContext('2d');
  let stars = [], width = 0, height = 0, dpr = 1;
  function seedStars() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth; height = window.innerHeight;
    canvas.width = width*dpr; canvas.height = height*dpr;
    canvas.style.width = width+'px'; canvas.style.height = height+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const count = Math.min(170, Math.floor(width*height/6500));
    stars = Array.from({length:count}, () => ({
      x:Math.random()*width, y:Math.random()*height,
      r:Math.random()*1.35+.25, a:Math.random()*.6+.15,
      phase:Math.random()*Math.PI*2, speed:Math.random()*.012+.002
    }));
  }
  function drawStars(t=0) {
    ctx.clearRect(0,0,width,height);
    stars.forEach(s => {
      const alpha = s.a * (prefersReduced ? 1 : (.68 + .32*Math.sin(t*s.speed+s.phase)));
      ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2);
      ctx.fillStyle = `rgba(255,235,249,${alpha})`; ctx.fill();
    });
    if (!prefersReduced) requestAnimationFrame(drawStars);
  }
  seedStars(); drawStars();
  window.addEventListener('resize', () => {seedStars(); if(prefersReduced) drawStars();});

  // Build the 19 candles.
  const candleBox = $('#candles');
  for(let i=0;i<19;i++){
    const candle=document.createElement('span');
    candle.className='candle';
    const flame=document.createElement('i'); flame.className='flame';
    candle.appendChild(flame); candleBox.appendChild(candle);
  }

  const scenes = $$('.scene');
  let current = 'home';
  function showScene(id) {
    const target = $('#'+id);
    if (!target) return;
    scenes.forEach(scene => {
      scene.classList.remove('active');
      scene.style.display = 'none';
    });
    target.style.display = 'flex';
    // Force a clean animation when revisiting a scene.
    void target.offsetWidth;
    target.classList.add('active');
    current = id;
    window.scrollTo({top:0,behavior:prefersReduced?'auto':'smooth'});
    if(id === 'finale') sparkleBurst(window.innerWidth/2, window.innerHeight*.45, 38);
  }
  function sparkleBurst(x,y,count=22) {
    const symbols=['✦','✧','♡','·','✴'];
    for(let i=0;i<count;i++){
      const el=document.createElement('span'); el.className='burst';
      el.textContent=symbols[Math.floor(Math.random()*symbols.length)];
      const angle=Math.random()*Math.PI*2, distance=35+Math.random()*130;
      el.style.setProperty('--x',x+'px'); el.style.setProperty('--y',y+'px');
      el.style.setProperty('--dx',Math.cos(angle)*distance+'px');
      el.style.setProperty('--dy',Math.sin(angle)*distance+'px');
      el.style.fontSize=(10+Math.random()*16)+'px';
      document.body.appendChild(el); setTimeout(()=>el.remove(),1000);
    }
  }

  $('#openCake').addEventListener('click', e => {
    $$('.flame').forEach((flame,i)=>setTimeout(()=>{flame.style.opacity='0';flame.style.transform='translateY(-10px) scale(.2)'},i*18));
    $('#cake').classList.add('cake-opened');
    sparkleBurst(window.innerWidth/2, window.innerHeight*.48, 30);
    const btn=e.currentTarget; btn.disabled=true; btn.innerHTML='A little wish just came true <span>♡</span>';
    setTimeout(()=>showScene('letter'),1100);
  });

  $$('.next-scene').forEach(btn => btn.addEventListener('click',()=>showScene(btn.dataset.next)));
  $('#finalReveal').addEventListener('click',()=>showScene('finale'));
  $('#replay').addEventListener('click',()=>{
    $$('.flame').forEach(flame=>{flame.style.opacity='1';flame.style.transform='';});
    $('#openCake').disabled=false; $('#openCake').innerHTML='Make a wish, birthday girl <span>✧</span>';
    showScene('home');
  });

  const notes = [
    'Your smile has a way of making an ordinary day feel special.',
    'I love the little things about you that you probably do not even notice.',
    'You do not have to do anything extraordinary to make me happy.',
    'I hope you never forget how beautiful you are, inside and out.',
    'I want to be there when your biggest dreams finally come true.',
    'You deserve love that feels peaceful, safe, and genuine.',
    'I love the thought of making countless little memories with you.',
    'Your happiness will always matter to me.',
    'I hope you laugh so much this year that your cheeks hurt.',
    'I want to celebrate your smallest wins as much as your biggest ones.',
    'You can grow, change, dream, and become whoever you want to be.',
    'I hope I can make even your difficult days a little softer.',
    'You deserve to be reminded of your worth, even on days you forget it.',
    'I want to know every version of you, not just the happy ones.',
    'Your dreams are important to me, and I will always cheer for you.',
    'If I could bottle up one feeling, it would be the happiness of seeing you smile.',
    'I hope 19 brings you beautiful surprises and wonderful new beginnings.',
    'No matter how much life changes, I hope we keep finding reasons to choose each other.',
    'If I had to choose my favourite person all over again, I would still choose you, Parthona. Every single time. ❤️'
  ];
  const grid=$('#notesGrid'), detail=$('#noteDetail'), noteText=$('#noteText');
  notes.forEach((note,i)=>{
    const button=document.createElement('button');
    button.type='button'; button.className='note-star'; button.setAttribute('aria-label',`Open love note ${i+1}`);
    button.innerHTML=`<span>${i%4===0?'♡':i%4===1?'✦':i%4===2?'✧':'✴'}</span><small>${String(i+1).padStart(2,'0')}</small>`;
    button.addEventListener('click',()=>{
      noteText.textContent=note; detail.classList.add('show');
      sparkleBurst(button.getBoundingClientRect().left+button.offsetWidth/2,button.getBoundingClientRect().top+button.offsetHeight/2,9);
      detail.scrollIntoView({behavior:prefersReduced?'auto':'smooth',block:'nearest'});
    });
    grid.appendChild(button);
  });
  $('#closeNote').addEventListener('click',()=>detail.classList.remove('show'));

  // Music opens an official search for the track instead of bundling copyrighted audio.
  const panel=$('#musicPanel');
  function openMusic(){panel.classList.add('open');panel.setAttribute('aria-hidden','false');}
  function closeMusic(){panel.classList.remove('open');panel.setAttribute('aria-hidden','true');}
  $('#musicToggle').addEventListener('click',()=>panel.classList.contains('open')?closeMusic():openMusic());
  $('#closeMusic').addEventListener('click',closeMusic);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMusic();detail.classList.remove('show');}});

  // Gentle touch/click sparkles; don't interfere with controls.
  document.addEventListener('pointerdown',e=>{
    if(e.target.closest('button,a')) return;
    if(Math.random()>.55) sparkleBurst(e.clientX,e.clientY,4);
  },{passive:true});
})();