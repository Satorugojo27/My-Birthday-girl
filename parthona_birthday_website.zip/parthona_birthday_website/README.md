# A Little Universe for Parthona ✨

A romantic, mobile-friendly birthday experience built with HTML, CSS, and JavaScript. No photos or backend are required; the universe and cake are drawn with CSS and a lightweight canvas starfield.

## Run it locally
1. Download and unzip the project.
2. Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new GitHub repository, for example `parthona-birthday`.
2. Upload `index.html`, `style.css`, `script.js`, and this README to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish your site. The URL will appear in the Pages settings.

This is a static site and uses relative paths, so it works on a GitHub Pages project URL.

## Music note
The music button opens a YouTube search for Ed Sheeran's official “Perfect” video. The site does not bundle or redistribute copyrighted audio. If you prefer, replace the link in `index.html` with the official authorised video URL.

## Personalise it
The messages are in `index.html` and the 19 note texts are in `script.js`. You can edit the wording without changing the animations.
